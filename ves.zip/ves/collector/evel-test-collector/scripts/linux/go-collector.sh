# Run the validating test collector.

python ../../code/collector/collector.py \
       --config ../../config/collector.conf \
       --section default \
       --verbose
