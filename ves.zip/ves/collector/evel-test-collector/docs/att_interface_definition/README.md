NOTE: This folder contains updates for the VES 5.0 release. 
* VNF Vendor Events ver 28.xlsx
* AttServiceSpecAddendum-VesEventListener-EventRegistration-v1.4.docx
* AttServiceSpecification-VesEventListener-v5.0.docx
* CommonEventFormat_28.0.json

The other files in this folder have not been updated. Compatibility with the current VES specification and code has not been verified.